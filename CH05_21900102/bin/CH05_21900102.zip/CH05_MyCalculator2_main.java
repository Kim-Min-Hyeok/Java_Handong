import java.util.*;
public class CH05_MyCalculator2_main {
	public static void main(String[] args) {
		CH05_MyCalculator2 myCal2 = new CH05_MyCalculator2();
		myCal2.getinput();
		myCal2.printresult();
	}
}
