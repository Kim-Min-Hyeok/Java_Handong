import java.util.*;
public class MySimpleCalculator {
	public static void main (String [] args)
	{
		System.out.println("Please input two numbers: ");
		int a, b;
		Scanner keyboard = new Scanner (System.in);
		a = keyboard.nextInt ();
		b = keyboard.nextInt ();
		System.out.print("a + b = ");
		System.out.println(a+b);		
		System.out.print("a - b = ");
		System.out.println(a-b);
		System.out.print("a * b = ");
		System.out.println(a*b);
		System.out.print("a / b = ");
		System.out.println(a/b);
	}
}
