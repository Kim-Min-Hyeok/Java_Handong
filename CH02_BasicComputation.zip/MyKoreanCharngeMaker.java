import java.util.*;
public class MyKoreanCharngeMaker {
	public static void main(String [] args)
	{
		System.out.println ("Enter a whole number from 1 to");
	    System.out.println ("10000.");
		int M;
		Scanner keyboard = new Scanner (System.in);
		M = keyboard.nextInt ();
		int m1=(M/500);
		int m2=(M%500)/100;
		int m3=(M%100)/10;
		int m4=(M%10)/5;
		int m5=(M%5);		
		System.out.println(M + " won in coins can be given as: ");
		System.out.println(m1 + " 500 won");
		System.out.println(m2 + " 100 won");
		System.out.println(m3 + " 10 won");
		System.out.println(m4 + " 5 won");
		System.out.println(m5 + " 1 won");
	}
}
