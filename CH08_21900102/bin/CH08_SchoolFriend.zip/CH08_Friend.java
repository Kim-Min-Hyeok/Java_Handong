
public class CH08_Friend {
	public void whatfriend() {
		System.out.println("We are friends");
	}

}
