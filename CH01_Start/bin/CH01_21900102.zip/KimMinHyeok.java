//�й� : 21900102 �̸� : �����
import java.util.Scanner;
public class KimMinHyeok {
	public static void main (String [] args) {
		System.out.println("Name : KimMinHyeok");
		System.out.println("University : Handong Global University");
		System.out.println("Student Number 12345678");
	}
}
